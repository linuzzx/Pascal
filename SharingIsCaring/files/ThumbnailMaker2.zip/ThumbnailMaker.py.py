import tkinter as tk
from tkinter import ttk, filedialog
from PIL import Image, ImageTk
import cv2

class ThumbnailExtractorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Thumbnail Maker")

        # Styling
        self.style = ttk.Style()
        self.style.theme_use('clam')  # You can experiment with different themes like 'alt', 'default', 'classic', etc.

        # Customize colors for dark mode theme
        self.root.tk_setPalette(background='#333333', foreground='white')
        self.style.configure('TLabel', foreground='white', background='#333333')  # Label text color
        self.style.configure('TButton', foreground='white', background='#444444', font=('Helvetica', 10, 'bold'), borderwidth=0, relief='flat', padding=5)  # Button text and background color
        self.style.configure('TFrame', background='#333333')  # Frame background color
        self.style.configure('TScale', troughcolor='#555555', sliderbackground='#888888')  # Scale colors
        self.style.configure('TSpinbox', foreground='black', background='#444444', font=('Helvetica', 10))  # Spinbox colors

        # Video Frame
        self.video_frame = ttk.Frame(root)
        self.video_frame.pack(fill="both", expand=True, padx=10, pady=10)

        self.canvas = tk.Canvas(self.video_frame, bg="#333333")  # Dark background for the video canvas
        self.canvas.pack(fill="both", expand=True)

        # Controls Frame
        self.controls_frame = ttk.Frame(root)
        self.controls_frame.pack(fill="x", padx=10, pady=5)

        # Open Button with an Icon (You need to add your own icon file)
        self.open_button = ttk.Button(self.controls_frame, text="Open Video", command=self.load_video)
        self.open_button.pack(side="left", padx=5)

        self.frame_spinbox = ttk.Spinbox(self.controls_frame, from_=0, to=0, width=10, command=self.update_frame_from_spinbox)
        self.frame_spinbox.pack(side="left", padx=5)

        self.scrollbar = ttk.Scale(self.controls_frame, from_=0, to=100, orient="horizontal", command=self.update_frame_from_scrollbar)
        self.scrollbar.pack(side="left", fill="x", expand=True, padx=5)

        self.export_button = ttk.Button(self.controls_frame, text="Export Thumbnail", command=self.export_thumbnail)
        self.export_button.pack(side="right", padx=5)

        self.cap = None
        self.total_frames = 0
        self.current_frame = 0
        self.frames_cache = {}
        self.cache_size = 5  # Adjust based on memory availability

        self.root.bind("<Left>", self.navigate_frames)
        self.root.bind("<Right>", self.navigate_frames)
        self.root.bind("<Up>", self.navigate_frames)
        self.root.bind("<Down>", self.navigate_frames)

        # Ensure canvas updates its size to current window
        self.canvas.bind("<Configure>", self.on_canvas_resize)

    def on_canvas_resize(self, event=None):
        # Redisplay current frame to adjust it to new canvas size
        self.display_frame(self.current_frame)

    def load_video(self):
        filepath = filedialog.askopenfilename()
        if filepath:
            self.cap = cv2.VideoCapture(filepath)
            self.total_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT)) - 1
            self.aspect_ratio = self.cap.get(cv2.CAP_PROP_FRAME_WIDTH) / self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
            self.scrollbar.config(to=self.total_frames - 1)
            self.frame_spinbox.config(from_=0, to=self.total_frames - 1)
            self.frames_cache.clear()
            self.update_frame(0, True)

    def get_frame(self, frame_no):
        if self.cap is None:
            return None
        if frame_no not in self.frames_cache:
            # Keep the cache within limits
            if len(self.frames_cache) >= self.cache_size:
                keys_to_remove = sorted(self.frames_cache.keys(), key=lambda k: abs(k-frame_no))[:-self.cache_size]
                for key in keys_to_remove:
                    del self.frames_cache[key]
            
            self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame_no)
            success, frame = self.cap.read()
            if success:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame = Image.fromarray(frame)
                self.frames_cache[frame_no] = frame
            else:
                return None
        return self.frames_cache[frame_no]

    def display_frame(self, frame_no):
        frame = self.get_frame(frame_no)
        if frame is None or self.canvas.winfo_width() == 1:  # Also check for canvas not being properly sized yet
            return

        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        frame_width, frame_height = frame.size
        scale_width = canvas_width / frame_width
        scale_height = canvas_height / frame_height
        scale = min(scale_width, scale_height)
        new_width = int(frame_width * scale)
        new_height = int(frame_height * scale)
        frame = frame.resize((new_width, new_height), Image.ANTIALIAS)

        self.video_image = ImageTk.PhotoImage(image=frame)
        self.canvas.create_image((canvas_width / 2, canvas_height / 2), image=self.video_image, anchor="center")

    def update_frame_from_scrollbar(self, val):
        frame_no = int(float(val))
        if frame_no != self.current_frame:
            self.update_frame(frame_no)

    def update_frame_from_spinbox(self):
        self.update_frame(int(self.frame_spinbox.get()))

    def update_frame(self, frame_no, load_video=False):
        if load_video or frame_no != self.current_frame:
            self.current_frame = frame_no
            self.scrollbar.set(frame_no)
            self.frame_spinbox.delete(0, tk.END)
            self.frame_spinbox.insert(0, str(frame_no))
            self.display_frame(frame_no)

    def export_thumbnail(self):
        frame = self.get_frame(self.current_frame)
        if frame:
            filetypes = [("JPEG files", "*.jpg"), ("PNG files", "*.png"), ("All files", "*.*")]
            filename = filedialog.asksaveasfilename(defaultextension=".jpg", filetypes=filetypes)
            if filename:
                frame.save(filename)
                print(f"Thumbnail exported as {filename}")

    def navigate_frames(self, event):
        if event.keysym == "Left":
            new_frame = max(self.current_frame - 1, 0)
        elif event.keysym == "Right":
            new_frame = min(self.current_frame + 1, self.total_frames - 1)
        elif event.keysym == "Up":
            new_frame = self.total_frames - 1
        elif event.keysym == "Down":
            new_frame = 0
        else:
            return  # No action for other keys

        self.update_frame(new_frame)

if __name__ == "__main__":
    root = tk.Tk()
    # root.iconbitmap('path_to_your_icon.ico')
    root.geometry("800x600")
    app = ThumbnailExtractorApp(root)
    root.mainloop()